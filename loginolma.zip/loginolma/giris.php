<?php 
session_start();
ob_start();


include("ayar.php");



?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>burası form sayfası</title>
</head>
<body>
<?php 

if (!empty($_COOKIE['kullanici'])) {

echo "giriş yaptınız başarılı..."."<br>";
echo "merhaba".@$_COOKIE['name'];
echo @$_COOKIE['kullanici'];
?>

<a href="welcome.php">çıkış için tıklayın</a>
<form action="welcome.php" method="post">
	
<button type="submit" name="kapa" value="cikis">Çıkış</button>


</form>
<?php 
}
else{
?>



<form action="calistir.php" method="post">
Ad:<input type="text" name="kadi"><br>
şifre:<input type="text" name="pass"><br>

<input type="checkbox" name="hatirla" value=""><br>
<button type="submit">Giris</button>


</form>


<?php 

}


?>



</body>
</html>