<?php 
session_start();
ob_start();
session_destroy();
include("ayar.php");

?>
çıkış yaptınız...
<?php




$baha = setcookie("name",$_SESSION['adi'],time()- 60*60);
$bati = setcookie("kullanici",$_SESSION['kullanici'],time()- 60*60);



header("Location: giris.php");







?>
