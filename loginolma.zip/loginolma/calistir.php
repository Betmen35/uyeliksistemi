<?php 
session_start();
ob_start();
include("ayar.php");


if (!empty($_POST['kadi']) && !empty($_POST['pass'])) {

$kadi= $_POST['kadi'];
$pass= $_POST['pass'];


$db= $veri->prepare("SELECT* FROM user WHERE adi=? AND sifre=?");
$db->bindParam(1,$_POST['kadi']);
$db->bindParam(2,$_POST['pass']);
$db->execute();

$dob= $db->rowCount();
$arap= $db->fetch();

if ($dob) {



$_SESSION['kullanici']=1;

$_SESSION['adi']= $arap['adi'];

$baha = setcookie("name",$_SESSION['adi'],time()+ 60*60);
$bati= setcookie("kullanici",$_SESSION['kullanici'],time()+ 60*60);
header("Location: giris.php");

}
else{

$_SESSION['kullanici']=0;
$_SESSION['adi']= $arap['adi'];

$baha = setcookie("name",$_SESSION['adi'],time()- 60*60);
$bati= setcookie("kullanici",$_SESSION['kullanici'],time()- 60*60);
header("Location: giris.php");

}




}








?>
