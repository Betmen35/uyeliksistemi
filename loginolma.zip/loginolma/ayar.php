<?php 


$veri= @new PDO("mysql:host=localhost;dbname=aktif",'root','',array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));

?>